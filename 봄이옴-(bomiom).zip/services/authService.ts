import { User } from '../types';

const STORAGE_KEY = 'momsbenefit_user';

// Mock function to simulate Kakao Login process
export const loginWithKakao = async (): Promise<{ id: string; nickname: string; email: string }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: 'kakao_' + Math.floor(Math.random() * 100000), // Random ID
        nickname: '예비맘', // Simulated nickname
        email: 'user@kakao.com',
      });
    }, 800);
  });
};

// Mock duplicate nickname check
const MOCK_TAKEN_NICKNAMES = ['admin', 'manager', 'root', 'mom', '임산부'];

export const checkNicknameAvailability = async (nickname: string): Promise<boolean> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate network delay
      const isTaken = MOCK_TAKEN_NICKNAMES.includes(nickname.trim());
      resolve(!isTaken);
    }, 300);
  });
};

// Save user to local storage
export const saveUser = (user: User) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
};

// Get user from local storage
export const getCurrentUser = (): User | null => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : null;
};

// Logout
export const logoutUser = () => {
  localStorage.removeItem(STORAGE_KEY);
};