import { Benefit, CategoryType } from '../types';

// Helper to get dynamic recent date for demo purposes
const getRecentDate = (daysAgo: number) => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
};

// Helper to generate random counts
const getRandomCount = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

// Mock Data
const MOCK_BENEFITS: Benefit[] = [
  // --- National Benefits (Common) ---
  {
    id: 'n1',
    title: '국민행복카드 임신·출산 진료비 지원',
    description: '임신 1회당 100만원 이용권 지원 (다태아 140만원)',
    source: 'GOV_NATIONAL',
    tags: ['바우처', '필수', '의료비'],
    category: 'GOV',
    ctaLink: '#',
    lastUpdated: '2024.01.01',
    likeCount: getRandomCount(1000, 5000),
  },
  {
    id: 'n2',
    title: '엽산제·철분제 무료 지원',
    description: '보건소 등록 임산부 대상 엽산제(임신일~3개월), 철분제(16주~분만전) 지급',
    source: 'GOV_NATIONAL',
    tags: ['무료', '영양제', '보건소'],
    category: 'FREE',
    ctaLink: '#',
    lastUpdated: getRecentDate(1), // Very recent
    updateType: 'UPDATE', // Marked as Updated
    likeCount: getRandomCount(500, 2000),
  },
  {
    id: 'n3',
    title: '임산부 친환경 농산물 꾸러미',
    description: '연간 48만원 상당(본인부담 20%) 친환경 농산물 구매 지원',
    source: 'GOV_NATIONAL',
    tags: ['먹거리', '할인'],
    category: 'LIFESTYLE',
    ctaLink: '#',
    lastUpdated: getRecentDate(15), 
    likeCount: getRandomCount(200, 800),
  },
  {
    id: 'n4',
    title: 'KTX/SRT 임산부 할인',
    description: '특실 좌석을 일반실 가격으로 이용 (맘편한 KTX)',
    source: 'GOV_NATIONAL',
    tags: ['교통', '할인'],
    category: 'DISCOUNT',
    ctaLink: '#',
    lastUpdated: '2023.12.20',
    likeCount: getRandomCount(300, 900),
  },

  // --- Local Benefits ---
  {
    id: 'l1',
    title: '임산부 교통비 70만원 지원',
    description: '지역 거주 6개월 이상 임산부 대상 교통 포인트 지급',
    source: 'GOV_LOCAL',
    tags: ['현금성', '교통', '지자체'],
    category: 'GOV',
    regionTarget: '서울', 
    ctaLink: '#',
    lastUpdated: getRecentDate(2),
    updateType: 'NEW', // Marked as New
    likeCount: getRandomCount(100, 500),
    envyCount: getRandomCount(2000, 5000), // High envy
  },
  {
    id: 'l2',
    title: '축하 웰컴 키트 선물',
    description: '손수건, 체온계, 아기 로션 등 필수 육아용품 박스 증정',
    source: 'GOV_LOCAL',
    tags: ['물품', '선물'],
    category: 'PACKAGE',
    regionTarget: '서울',
    ctaLink: '#',
    lastUpdated: '2024.04.20',
    likeCount: getRandomCount(50, 200),
    envyCount: getRandomCount(500, 1500),
  },
  {
    id: 'l3',
    title: '산후조리비 50만원 지원',
    description: '지역화폐로 산후조리비용 지원 (소득 무관)',
    source: 'GOV_LOCAL',
    tags: ['지원금', '산후조리'],
    category: 'GOV',
    regionTarget: '경기',
    ctaLink: '#',
    lastUpdated: getRecentDate(5),
    updateType: 'UPDATE', // Marked as Update
    likeCount: getRandomCount(100, 400),
    envyCount: getRandomCount(1000, 3000),
  },
  {
    id: 'l4',
    title: '광안대교 통행료 면제',
    description: '임산부 탑승 차량 유료도로 통행료 면제 (사전 등록 필수)',
    source: 'GOV_LOCAL',
    tags: ['교통', '면제'],
    category: 'DISCOUNT',
    regionTarget: '부산',
    ctaLink: '#',
    lastUpdated: getRecentDate(10),
    likeCount: getRandomCount(50, 150),
    envyCount: getRandomCount(300, 800),
  },
  {
    id: 'l5',
    title: '맘편한 태교 여행비 지원',
    description: '도내 호텔/리조트 이용 시 1박 숙박권(20만원 상당) 지원',
    source: 'GOV_LOCAL',
    tags: ['여행', '휴식'],
    category: 'LIFESTYLE',
    regionTarget: '강원',
    ctaLink: '#',
    isRecommended: true,
    lastUpdated: getRecentDate(3),
    updateType: 'NEW',
    likeCount: getRandomCount(80, 200),
    envyCount: getRandomCount(3000, 6000), // Very High envy
  },
  {
    id: 'l6',
    title: '유기농 이유식 재료 배송',
    description: '지역 농산물로 구성된 초기 이유식 키트 월 1회 배송',
    source: 'GOV_LOCAL',
    tags: ['육아', '먹거리'],
    category: 'PACKAGE',
    regionTarget: '전남',
    ctaLink: '#',
    lastUpdated: '2024.03.10',
    likeCount: getRandomCount(30, 100),
    envyCount: getRandomCount(200, 600),
  },
  {
    id: 'l7',
    title: '임산부 가사돌봄 서비스',
    description: '출산 전후 1개월간 가사 도우미 파견 (일 4시간)',
    source: 'GOV_LOCAL',
    tags: ['돌봄', '편의'],
    category: 'LIFESTYLE',
    regionTarget: '광주',
    ctaLink: '#',
    isRecommended: true,
    lastUpdated: getRecentDate(20),
    likeCount: getRandomCount(40, 120),
    envyCount: getRandomCount(800, 2000),
  },

  // --- Private Benefits ---
  {
    id: 'p1',
    title: '국민 태아보험 무료 견적 + 사은품',
    description: '복잡한 태아보험, 1분 만에 비교하고 아기띠 받기',
    source: 'PRIVATE',
    tags: ['보험', '상담'],
    category: 'FINANCE',
    ctaLink: '#',
    isRecommended: true,
    lastUpdated: getRecentDate(1),
    updateType: 'NEW',
  },
  {
    id: 'p2',
    title: '프리미엄 기저귀 샘플팩 0원 체험',
    description: '배송비만 내고 인기 브랜드 기저귀 4종 체험하기',
    source: 'PRIVATE',
    tags: ['무료체험', '샘플'],
    category: 'FREE',
    ctaLink: '#',
    isRecommended: true,
    lastUpdated: '2024.03.01',
  },
  {
    id: 'p3',
    title: '임산부 전용 요가 클래스 50% 할인',
    description: '집에서 편하게 듣는 온라인 라이브 클래스 첫 달 반값',
    source: 'PRIVATE',
    tags: ['운동', '할인'],
    category: 'LIFESTYLE',
    ctaLink: '#',
  },
  {
    id: 'p4',
    title: '성장앨범 만삭 촬영 무료 이벤트',
    description: '지역 제휴 스튜디오에서 만삭 사진 무료 촬영 및 액자 증정',
    source: 'PRIVATE',
    tags: ['촬영', '무료'],
    category: 'LIFESTYLE',
    ctaLink: '#',
  },
];

// Helper to simulate "keyword matching" for regions
const matchRegion = (inputRegion: string, targetRegion?: string) => {
  if (!targetRegion) return false;
  return inputRegion.includes(targetRegion) || targetRegion.includes(inputRegion);
};

export const fetchBenefits = async (region: string): Promise<Benefit[]> => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 600));

  return MOCK_BENEFITS.map((benefit) => {
    // If it's a local benefit, check if it matches the region
    if (benefit.source === 'GOV_LOCAL') {
       // Simple mock logic
       let normalizedInput = region;
       if (region.includes('서울')) normalizedInput = '서울';
       else if (region.includes('경기') || region.includes('분당') || region.includes('성남') || region.includes('수원')) normalizedInput = '경기';
       else if (region.includes('부산')) normalizedInput = '부산';
       else if (region.includes('강원')) normalizedInput = '강원';
       else if (region.includes('전남')) normalizedInput = '전남';
       else if (region.includes('광주')) normalizedInput = '광주';
       
       if (matchRegion(normalizedInput, benefit.regionTarget)) {
         return benefit;
       }
       return null;
    }
    return benefit;
  }).filter((b): b is Benefit => b !== null);
};

// Get all local benefits (No longer excludes user region per request)
export const getAllLocalBenefits = async (excludeRegion?: string): Promise<Benefit[]> => {
   await new Promise((resolve) => setTimeout(resolve, 500));
   
   // Simply return all local benefits
   return MOCK_BENEFITS.filter(b => b.source === 'GOV_LOCAL');
};

export const filterBenefitsByCategory = (benefits: Benefit[], category: CategoryType): Benefit[] => {
  if (category === 'ALL') return benefits;
  
  if (category === 'GOV') {
    return benefits.filter(b => b.source === 'GOV_NATIONAL' || b.source === 'GOV_LOCAL');
  }

  return benefits.filter(b => b.category === category);
};