import React, { useState, useEffect } from 'react';
import { Benefit } from '../types';
import { ChevronRight, ExternalLink, Clock, Sparkles, Heart, RefreshCw } from 'lucide-react';

interface Props {
  benefit: Benefit;
  userRegion?: string;
  mode?: 'LIKE' | 'ENVY'; // Explicit mode control
}

// Helper to check if the benefit was updated within the last 30 days
const isRecentUpdate = (dateString?: string) => {
  if (!dateString) return false;
  try {
    const parts = dateString.split('.');
    if (parts.length !== 3) return false;
    // YYYY.MM.DD
    const date = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    const now = new Date();
    
    // Check if valid date
    if (isNaN(date.getTime())) return false;
    
    // Calculate difference in days
    const diffTime = now.getTime() - date.getTime();
    const diffDays = diffTime / (1000 * 3600 * 24);
    
    // Return true if updated within last 30 days
    return diffDays >= 0 && diffDays <= 30;
  } catch (e) {
    return false;
  }
};

export const BenefitCard: React.FC<Props> = ({ benefit, userRegion, mode = 'LIKE' }) => {
  const isPrivate = benefit.source === 'PRIVATE';
  const isGov = benefit.source.includes('GOV');
  const isRecent = isRecentUpdate(benefit.lastUpdated);
  
  // Determine Badge Type
  const showBadge = isRecent && (benefit.updateType === 'NEW' || benefit.updateType === 'UPDATE');
  const badgeType = benefit.updateType || (isRecent ? 'NEW' : null);

  // Check if this benefit belongs to the user's region
  const isMyRegion = userRegion && benefit.regionTarget && userRegion.includes(benefit.regionTarget);

  // Persistence Logic
  const storageKey = `momsbenefit_like_${benefit.id}`;
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(() => {
    // Initialize count based on mode
    const initialCount = mode === 'ENVY' ? (benefit.envyCount || 0) : (benefit.likeCount || 0);
    
    // Check local storage
    const stored = localStorage.getItem(storageKey);
    const isLiked = stored === 'true';
    
    setLiked(isLiked);
    setCount(isLiked ? initialCount + 1 : initialCount);
  }, [benefit.id, mode, storageKey, benefit.envyCount, benefit.likeCount]);

  const handleReaction = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const newLikedState = !liked;
    setLiked(newLikedState);
    setCount(prev => newLikedState ? prev + 1 : prev - 1);
    
    localStorage.setItem(storageKey, String(newLikedState));
  };

  return (
    <div className={`
      relative overflow-hidden rounded-2xl border transition-all duration-200 flex flex-col h-full group
      ${isPrivate 
        ? (showBadge ? 'bg-white border-rose-300 shadow-md ring-1 ring-rose-200' : 'bg-white border-rose-100 hover:border-rose-300 shadow-sm') 
        : (showBadge ? 'bg-white border-blue-300 shadow-md ring-1 ring-blue-100' : 'bg-white border-gray-100 hover:border-gray-300 shadow-sm')
      }
    `}>
      {/* Absolute Badge - Positioned Top Right */}
      {showBadge && (
        <div className="absolute top-0 right-0 z-10">
          {badgeType === 'NEW' ? (
             <div className="bg-red-500 text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl shadow-sm flex items-center gap-1">
               <Sparkles size={10} fill="currentColor" /> NEW
             </div>
          ) : (
             <div className="bg-blue-500 text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl shadow-sm flex items-center gap-1">
               <RefreshCw size={10} /> UPDATE
             </div>
          )}
        </div>
      )}

      <div className="p-5 flex flex-col flex-grow h-full">
        {/* Header: Badges & Tags */}
        {/* Added pr-16 to prevent overlap with the absolute badge */}
        <div className="flex flex-wrap items-center gap-2 mb-3 pr-16 min-h-[24px]">
           {/* Region Badge (if exists) */}
           {benefit.regionTarget && (
             <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-1 rounded-[4px] shadow-sm">
                {benefit.regionTarget}
             </span>
           )}

           {/* Source Badge */}
           <span className={`
              text-[10px] font-bold px-2 py-1 rounded-[4px] tracking-wide
              ${benefit.source === 'GOV_NATIONAL' ? 'bg-blue-100 text-blue-700' : ''}
              ${benefit.source === 'GOV_LOCAL' && !benefit.regionTarget ? 'bg-emerald-100 text-emerald-700' : ''} 
              ${benefit.source === 'PRIVATE' ? 'bg-rose-100 text-rose-600' : ''}
            `}>
              {benefit.source === 'GOV_NATIONAL' && '전국 공통'}
              {benefit.source === 'GOV_LOCAL' && !benefit.regionTarget && '지자체 혜택'}
              {benefit.source === 'PRIVATE' && '제휴 혜택'}
            </span>
            
            {/* Feature Tags */}
            {benefit.tags.map((tag, idx) => (
              <span key={idx} className="text-[10px] text-gray-500 bg-gray-50 px-2 py-1 rounded-[4px]">
                #{tag}
              </span>
            ))}
        </div>

        {/* Content */}
        <h3 className="text-lg font-bold text-gray-900 mb-1 leading-snug group-hover:text-rose-600 transition-colors">
          {benefit.title}
        </h3>
        <p className="text-sm text-gray-600 mb-4 leading-relaxed flex-grow">
          {benefit.description}
        </p>

        {/* Footer Area */}
        <div className="mt-auto">
          {benefit.lastUpdated && (
            <div className={`flex items-center gap-1 text-[11px] mb-3 ${showBadge ? 'text-gray-800 font-semibold' : 'text-gray-400'}`}>
              <Clock size={11} />
              <span>
                {showBadge ? '최근 업데이트: ' : '업데이트: '} {benefit.lastUpdated}
              </span>
            </div>
          )}
          
          <div className="flex gap-2">
            <a 
              href={benefit.ctaLink}
              onClick={(e) => e.preventDefault()}
              className={`
                flex-grow flex items-center justify-center gap-1 py-3 rounded-xl text-sm font-semibold transition-colors
                ${isGov 
                  ? 'bg-gray-50 text-gray-700 hover:bg-gray-100 border border-gray-200' 
                  : 'bg-rose-500 text-white hover:bg-rose-600 shadow-rose-200 shadow-md'
                }
              `}
            >
              {isGov ? (
                <>
                  공식 안내 <ExternalLink size={14} className="ml-1 opacity-60" />
                </>
              ) : (
                <>
                  혜택 받기 <ChevronRight size={16} />
                </>
              )}
            </a>
            
            {/* Reaction Button Logic */}
            {mode === 'ENVY' && isMyRegion ? (
              // Case: Envy Mode but it's MY region -> Show "My Region" Badge
              <div className="flex items-center justify-center gap-1 px-3 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-600 font-bold text-xs min-w-[60px]">
                 <span>🙆</span>
                 <span className="text-[10px]">내 거주지</span>
              </div>
            ) : (
              // Standard Button (Like or Envy)
              <button 
                onClick={handleReaction}
                className={`
                  flex items-center gap-1 px-3 rounded-xl border font-bold text-xs transition-all min-w-[60px] justify-center
                  ${liked 
                    ? (mode === 'ENVY' ? 'bg-purple-100 border-purple-200 text-purple-600' : 'bg-rose-100 border-rose-200 text-rose-600') 
                    : 'bg-white hover:bg-gray-50 border-gray-200 text-gray-500'}
                `}
              >
                {mode === 'ENVY' ? (
                  <>
                    <span className="text-lg">🥺</span>
                    <div className="flex flex-col items-start leading-none ml-1">
                      <span className="text-[9px] opacity-70">부러워요</span>
                      <span>{count.toLocaleString()}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <Heart size={16} fill={liked ? "currentColor" : "none"} className={liked ? "text-rose-600" : "text-gray-400"} />
                    <span>{count.toLocaleString()}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};